java -cp lib/hsqldb.jar org.hsqldb.Server
